	
	
#ifdef __ASSEMBLY__
	
	@;offsets in bytebuf struct TODO: convert to CONTAINER/ELEMENT
	.equ bytebufBUFPTR,0
	.equ bytebufDATAPTR,4
	.equ bytebufCURRCOUNT,8
	.equ bytebufMAXCOUNT,12
	
#else 
		
	#include <stdint.h>	//for int32_t, etc
	#include <stddef.h>	//for size_t()

	//'bytebuf_t' buffer control structure
	//These are placed in separate sections in SRAM3 to control buffers used to transfer data between processes in CM4 and CM7
	typedef struct 
	{
		uint8_t *bufptr;	//origin of buffer 
		uint8_t *dataptr;	//location of next free write location in write mode (currcount<=0); location of next available byte in read mode (currcount>0)
		int32_t currcount;	//current number of entries
		int32_t maxcount;	//maximum number of entries permitted = size of buffer allocation
	} bytebuf_t;

	uint8_t * bytebuf_init(bytebuf_t *bufctl, uint8_t *buf, size_t size); //initialize bufptr, dataptr, currentcount, and maxcount of a bytebuf_t. 
	int32_t bytebuf_wr(bytebuf_t *bufctl, uint8_t data ); //write data to buffer. Return number remaining to write 
	int32_t bytebuf_rd(bytebuf_t *bufctl, uint8_t *data ); //read data from buffer. Return number remaining to read 
	int32_t bytebuf_wrstop(bytebuf_t *bufctl); 				// stop the write phase for turnover to consumer process
	int32_t bytebuf_rdstop(bytebuf_t *bufctl); 				// stop the read phase for turnover to producer process
	int32_t bytebuf_count( bytebuf_t *bufctl ); 			//report magnitude of current count. Values <=0 indicate write-phase, >0 indicate read-phase
	uint8_t * bytebuf_reset(bytebuf_t *bufctl);	//reset buffer control to initial values
	
#endif