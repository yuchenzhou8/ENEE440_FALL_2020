//CM4main01.c for scratch build wmh 2020-08-07 : main() blinks yellow LED using SysTick time 

	#include <stdint.h>
	
	struct SysTick_shmem {
		uint64_t SysTick_absmsecs;	// 
		uint32_t SysTick_msecs;		// ""
		uint32_t SysTick_secs;		// ""
	};
	
	
	//Define a CM4 global struct instance which accesses the shared memory containing the SysTick values
	//see https://gcc.gnu.org/onlinedocs/gcc/Common-Variable-Attributes.html#index-section-variable-attribute
	struct SysTick_shmem SysTick __attribute__((section(".SysTick_shmem"))); 

	void initGPIOEBIT1();	//initialize port bit controlling yellow LED
	void toggleGPIOEBIT1();	// flip port bit controlling yellow LED to its opposite state	
	
	
int main() 
{
	
	initGPIOEBIT1();	//initialize port bit controlling yellow LED
	
	while(1) {	//forever
		while(SysTick.SysTick_msecs < 500); 	//trap here for 1/2 second
		toggleGPIOEBIT1();						//then toggle the yellow LED
		while(SysTick.SysTick_msecs >= 500); 	// then trap here for 1/2 second
		toggleGPIOEBIT1();						//then toggle the yellow LED again
	}											// and go up to wait some more
		
	return 0;	//eliminate warning
}