// Yuchen Zhou
// 12/16/20
// ENEE440 Microprocessor Final Project


// used library
#include <stdint.h>				//for uint32_t and friends
#include <stddef.h>				//for NULL
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14159265

void initSysTick64MHz();
extern uint64_t SysTick_absmsecs;	//in SysTick64MHz.S
extern uint32_t SysTick_msecs;		// ""
extern uint32_t SysTick_secs;		// ""
extern uint32_t immediate_push;
extern uint32_t repetitive_push;

extern uint32_t pulse_length_msec;
extern uint32_t pulse_period_msec;

//. in ADC3interrupt_EOC.S
uint16_t ADC3_buf0[512];	//
uint32_t ADC3_IRQcount = 0;
uint32_t ADC3_deltacount;

uint32_t inp_0 = 0;					// push button deboucing implementation
uint32_t inp_1 = 0;					// push button deboucing implementation

//GPIO
void initGPIOxBITn();				//in GreenLED.S
void setGPIOxBITn();				// ""
void resetGPIOxBITn();				// ""

//USART3 initialization and test operations
void USART3_HWinit();
void USART3_IRQinit(); 
int nbUSART3_getchar(); 			//success: return data>=0; failure: return -1
int nbUSART3_putchar(char data);	//success: return +1; failure: return -1)_
void USART3_TXinterrupt_enab();		//

//TIM1 function
void GPIO_A_Config();
void pulse_input_report();

//ADC3 function
void PC2_init(); 		//configure PC2 as an analog input
void ADC3_init();		//enable, reset and calibrate ADC3 (does not configure or enable ADC3)
void ADC3_config_06(); 	//configure ADC3 for continuous conversion of PC2 with overrun using extended sampling time
uint32_t ADC3_start();
void initialize_ADC3_PC2();	 // configure all device registers to be ready to start converting
void start_ADC3_conversion(); // start convert input analog signal

//DAC function
void GPIOA4_init();
void DAC_DHR12R1_Config2(uint32_t digital_voltage);
void DAC_PWM();
extern uint32_t DAC_pulse_count;
extern uint32_t DAC_pulse_threshold;
extern uint32_t dig_voltage_level;
extern uint32_t current_DAC_PWM_state;
extern uint32_t  dac_pwm_state;
extern uint32_t dac_sine_state;
extern uint32_t dac_sine_period;
extern uint32_t dac_sine_count;

//command processing
int hexcmd2bin(char *hexcmd, uint8_t *bincmd);	//processes a text buffer containing a MoT-format command 'string'  into a binary command buffer; 
												//	returns #of bytes in bincmd or -1 if format violation

void *Reset_Handler();				//in startup/startup_stm32CM7.S
void *cmd_greenLED(void *);			//in CM7/src/device_greenLED.S 
void *cmd_TIM1(void *);
void *cmd_ADC3(void *);
void *cmd_DAC(void *);
void *(*CM7_cmdTable[])(void *) = {Reset_Handler,cmd_greenLED,cmd_TIM1,cmd_ADC3,cmd_DAC};

#define MAXHEXBUF 100
char output[MAXHEXBUF];

int main() 
{
	PC2_init();
	int c,ret;
	char USART3_hexbuf[MAXHEXBUF];					//where 'raw' commands received ver UART3 are accumulated (global for later useage) 
	uint8_t USART3_binbuf[MAXHEXBUF/2+1];			//where converted commands from UART3_hexbuf[] are stored           --"--
	char *phexbuf=USART3_hexbuf;
	uint8_t *pbinbuf=USART3_binbuf;
	char *pmsg="\nCM7 testy starting\n";

	// Device initialization
	USART3_HWinit();								//initalize USART3 for serial communication
	initSysTick64MHz();                             //enable systick and using the IRQ to handle the blink request
	GPIO_A_Config();								//configure portA0 for pulse verification
	GPIOA4_init();									//configure portA4 for DAC channel 1 output

	//send startup message
	if(pmsg != NULL) { 			//there is some message to be sent
		while( *pmsg != '\0') {	//	there remains message to be sent
			while( nbUSART3_putchar(*pmsg)<0) ;	//the current character has not been sent until we are released from this while()
			pmsg++;
		}
	}
	
	while(1){ //interpret and execute commands
		if( (c = nbUSART3_getchar()) >= 0 ){ 	//we have received a new character
			*phexbuf++=c;						//	so put it in the command buffer
			if( (c=='\n') || (c=='\r') ) {		//	if its a newline we may have a new command (if it passes the format check)
				if( (ret=hexcmd2bin(USART3_hexbuf,USART3_binbuf))>0 ) { 		//it passed the format check
					pmsg= CM7_cmdTable[USART3_binbuf[0]](&USART3_binbuf[1]);	//	dispatch a device function !!TODO check fit to limits of function array
					if(pmsg != NULL) { 			//there is some message to be sent
						while( *pmsg != '\0') {	//	there remains message to be sent 	
							while( nbUSART3_putchar(*pmsg)<0) ;	//the current character has not been sent until we are released from this while()
							pmsg++;
						}
					}
					//here with the message (if any) sent
				}
				//here after the current hex buffer processing is finished 
				phexbuf=USART3_hexbuf;	//restart the input buffer
			}
			// debug : nbUSART3_putchar((char)c);		//echo it back (overruns are prevented by RX pacing)
		}
	}

	return 0;	//eliminates a warning
}

int hex2bin(char HASCII)   // translate uppercase hex ASCII to bin, return value 0-15 or -1 if fail
{   
	if('0'<=HASCII && '9'>=HASCII) return(HASCII - '0');   
	if('A'<=HASCII && 'F'>=HASCII) return(HASCII - 'A' + 10);  
	return -1;   
}   


int hexcmd2bin(char *hexcmd, uint8_t *bincmd)	//processes a text buffer containing a MoT-format command 'string'  into a binary command buffer; 
//	returns #of bytes in bincmd or -1 if format violation
{
	int i;
	uint8_t lonybble,hinybble,byte;
	uint8_t chk=0;
	if(hexcmd[0] != ':' ) return -1;	//bad format -- no start symbol
	for(i=1;i<MAXHEXBUF;) {
		if( (hexcmd[i]=='\n')| (hexcmd[i]=='\r')) break;//we're at the end of a command
		//here if parsing should continue
		if( ((hinybble=hex2bin(hexcmd[i]))>=0) && ((lonybble=hex2bin(hexcmd[i+1]))>=0) ) byte=16*hinybble+lonybble; //successful hex byte to bin conversion  
		else return -2;					//bad hex byte
		//here when the two characters of a hex byte are successfully converted into a value in 'byte'
		*bincmd++ = byte;				//add byte to the binary cmd string
		chk += byte;					// and to the checksum (overflows are expected and desired)
		i += 2;							//  then advance to convert the next byte
	}
	//here iff the text string lies between ':' and '\n' or '\r' and consists exclusively of hex bytes
	if ( chk != 0 ) return -3;			//bad checksum	
	return i/2-1;						//number of bytes in bindcmd, not including checksum
}


//*******************************Helper C function for different devices************************************************************

// checker for the deboucing implementation of the push button, see if a valid push is received
int ready_toggle(){
	if(inp_1 == 1 && inp_0 >= 3){
		inp_1 = 0;
		inp_0 = 0;
		return 1;
	}else{
		return 0;
	}
}

// update immediate/repetitive mode of push button
int push_mode(){
	if(immediate_push)
	{
		immediate_push = 0;
		return 1;
	}else if(repetitive_push){
		return 1;
	}else{
		return 0;
	}
}

// generate a report message about the input PWM/PFM duration and period
void pulse_input_report(){

	char num_string_1[100];
	char num_string_2[100];
	int i,j,k;
	itoa(pulse_length_msec,num_string_1,10);
	itoa(pulse_period_msec,num_string_2,10);

	sprintf(output, "duration:     ms, period:     ms\n");
	for(i = 0, k = 0; i < strlen(output); i++){
		if(output[i] == ':' && !k){
			i = i + 2;
			k = k + 1;
			for(j = 0; j < strlen(num_string_1);j++, i++){
				output[i] = num_string_1[j];
			}
		}
		if(output[i] == ':' && k){
			i = i + 2;
			k = k + 1;
			for(j = 0; j < strlen(num_string_2);j++, i++){
				output[i] = num_string_2[j];
			}
		}
	}

}


// ADC functions that initializes PIN PC2 as analog input for ADC input
void initialize_ADC3_PC2(){
	PC2_init();			//prep PC2 for input to ADC3
	ADC3_init();
	ADC3_config_06();
}

// ADC functions that triggers the conversion process
void start_ADC3_conversion(){
	ADC3_start();
}

// DAC functions that toggles the PWM wave between high and low
void DAC_PWM(){
	DAC_pulse_count -= 1;
	if(!DAC_pulse_count){
		current_DAC_PWM_state += 1;
		current_DAC_PWM_state = current_DAC_PWM_state%2;
		if(current_DAC_PWM_state) DAC_DHR12R1_Config2(dig_voltage_level);
		else DAC_DHR12R1_Config2(0);
		DAC_pulse_count = DAC_pulse_threshold;
	}
}

// DAC functions that calculates current voltage level of a sine wave based on time (0-4095), update the analog output of DAC
void DAC_SINE(){
	float voltage = (sin(2*PI*(1.0/((float)(dac_sine_period*.001)))*dac_sine_count*.001) + 1) / 2.0;
	int digital_level = (int)round(voltage * 4095);
	DAC_DHR12R1_Config2(digital_level);
	dac_sine_count += 1;
	dac_sine_count %= dac_sine_period;

}
